/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package horsesactivity;

/**
 *
 * @author User
 */
public class RaceHorse extends Horse{
    public int numOfRaces;
    
    public RaceHorse(String name, String color, int birthYear, int numOfRaces){
        super(name, color, birthYear);
        this.numOfRaces = numOfRaces;
    }
    
    public int getNumOfRaces(){
        return numOfRaces;
    }
    
    public void setNumOfRaces(int numOfRaces){
        this.numOfRaces = numOfRaces;
    }
}
