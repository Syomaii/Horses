/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package horsesactivity;

/**
 *
 * @author User
 */
public class HorsesActivity {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Horse horse1 = new Horse("Spirit", "Black", 2010);

        // Display information about the horse
        System.out.println("Horse Information:");
        System.out.println("Name: " + horse1.getName());
        System.out.println("Color: " + horse1.getColor());
        System.out.println("Birth Year: " + horse1.getBirthYear());

        // Create an instance of the RaceHorse class
        RaceHorse raceHorse1 = new RaceHorse("Speedy", "Brown", 2012, 15);

        // Display information about the race horse
        System.out.println("\nRace Horse Information:");
        System.out.println("Name: " + raceHorse1.getName());
        System.out.println("Color: " + raceHorse1.getColor());
        System.out.println("Birth Year: " + raceHorse1.getBirthYear());
        System.out.println("Number of Races: " + raceHorse1.getNumOfRaces());

        // Update the information for the race horse
        raceHorse1.setNumOfRaces(20);

        // Display updated information
        System.out.println("\nUpdated Race Horse Information:");
        System.out.println("Name: " + raceHorse1.getName());
        System.out.println("Color: " + raceHorse1.getColor());
        System.out.println("Birth Year: " + raceHorse1.getBirthYear());
        System.out.println("Number of Races: " + raceHorse1.getNumOfRaces());
    }
    
}
